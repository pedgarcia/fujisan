Fujisan Portable - Modern Atari 8-bit Emulator
===============================================

Version: 1.0.0

To run Fujisan:
1. Extract this archive to any directory
2. Run: ./fujisan.sh

Requirements:
- Linux x86_64
- glibc 2.31+ (Ubuntu 20.04+, Debian 11+, RHEL/Rocky 8+)
- Basic OpenGL support
- X11 display server

This package includes all required Qt5 libraries and plugins.

For system-wide installation, use the .deb package instead.

Visit: https://github.com/atari800/fujisan
