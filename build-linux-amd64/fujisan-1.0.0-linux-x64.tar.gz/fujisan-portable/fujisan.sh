#!/bin/bash
# Fujisan Portable Launcher
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# Note: qt.conf (in bin/) prevents Qt from searching system plugin paths
export LD_LIBRARY_PATH="$SCRIPT_DIR/lib"
export FUJISAN_IMAGES_PATH="$SCRIPT_DIR/images"
# Disable KDE platform theme integration to prevent loading system Qt plugins
export QT_QPA_PLATFORMTHEME=""
# Use bundled Fusion style for consistent cross-platform appearance
export QT_STYLE_OVERRIDE="Fusion"

exec "$SCRIPT_DIR/bin/Fujisan" "$@"
